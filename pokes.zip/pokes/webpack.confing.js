const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
    entry: './resources/js/app.js',
    output: {
      path: path.resolve(__dirname, 'public'),
      filename: 'js/app.js',
    },
    module: {
        rules: [
          {
            test: /\.vue$/,
            loader: 'vue-loader',
          },
        ],
      },
      
      plugins: [
        new HtmlWebpackPlugin({
          template: './resources/views/index.blade.php',
          filename: '../resources/views/index.blade.php',
        }),
      ],
      
    // Configura otras opciones según tus necesidades
  };
  
