<?php if(session('status')): ?>
	<?php echo e(session('status')); ?>

<?php endif; ?><?php /**PATH C:\laragon\www\intento\resources\views/partials/session-status.blade.php ENDPATH**/ ?>