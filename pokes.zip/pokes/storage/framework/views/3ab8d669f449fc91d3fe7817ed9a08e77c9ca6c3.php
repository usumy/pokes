<?php $__env->startSection('title', 'editar Productos'); ?>
<?php $__env->startSection('content'); ?>
<h1>Editar Productos
 </h1>

<?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form method="POST" action="<?php echo e(route('projects.update',$project)); ?>">
	 <?php echo method_field('PATCH'); ?>

	<?php echo $__env->make('projects._form',['btnText'=>'Actualizar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\intento\resources\views/projects/edit.blade.php ENDPATH**/ ?>