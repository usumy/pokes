<?php echo csrf_field(); ?>
	<div class="form-group">
		<label for="title"> Titulo del Productos </label>
			<input 
			id="title"
			type="text" 
			name="title" 
			value="<?php echo e(old('title', $project->title)); ?>">
		
	</div>

	<div class="form-group">
		<label for="url"> URL del Producto </label>
			<input  class="form-control border-0 bg-light shadow-sm"
			 id="url"
			 type="text" 
			 name="url" 
			 value="<?php echo e(old('url', $project->url)); ?>">
		
	</div>
	<div class="form-group">
		<label for="description"> Descripción del Productos </label>
		<textarea
		class="form-control border-0 bg-light shadow-sm" 
		name="description">
		<?php echo e(old('description', $project->description)); ?>

		</textarea>
	
	</div>
	<p>selecione una imagen a cargar</p>
        <div class="form-group">
          <label class="col-sm-2 control-label">Archivos</label>
          <div class="col-sm-8">
            <input type="file" class="form-control"
			 id="imagen" 
			 name="imagen" multiple> 
			 <?php echo e(old('imagen,$project->imagen')); ?>

          </div>
        </div>
	<button class="btn btn-primary btn-block"> <?php echo e($btnText); ?> </button>
	<a class="btn btn-link btn-block " 
	href="<?php echo e(route('projects.index')); ?>">
	Cancelar </a><?php /**PATH C:\laragon\www\planti\resources\views/projects/_form.blade.php ENDPATH**/ ?>