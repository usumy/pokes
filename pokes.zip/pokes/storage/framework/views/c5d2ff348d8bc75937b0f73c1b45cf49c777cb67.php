<?php $__env->startSection('title', 'Productos | '. $project->title); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="bg-white p-5 shadow rounded">
		<h1><?php echo e($project->title); ?></h1>
		<div class="col-10 col-lg-5">
			<img src="<?php echo e(asset('$project->imagen')); ?>" alt="Imagen de ejemplo">
			<img  class="img-fluid mb-4" src="<?php echo e($project->imagen); ?>" alt="En unos momentos le muestro la imagen">
			
		</div>
		
		<img src="<?php echo e(asset($project)); ?>" alt="">
		<p class="text-secondary">
			<?php echo e($project->description); ?></p>
		<p class="text-black-50">
			<?php echo e($project->created_at->diffForHumans()); ?></p>
		<div class="d-flex justify-content-between
		alinf-items-center">
			<a href="<?php echo e(route('projects.index')); ?>">Regresar</a>
			<form action="<?php echo e(route('cart.add')); ?>" method="POST">

<?php echo csrf_field(); ?>

<input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">

<button type="submit">Agregar al carrito</button>

</form>

			
				
			<?php if(auth()->guard()->check()): ?>
			<div class="btn-group btn-group-sm">
				<a class="btn btn-primary"
				href="<?php echo e(route('projects.edit',$project)); ?>">
				Editar</a>
				
				
				
			</div>
			<form  
				method="POST" 
				action="<?php echo e(route('projects.destroy', $project)); ?>">
				<?php echo csrf_field(); ?>  <?php echo method_field('DELETE'); ?>
				<button>Eliminar</button>
				</form>
			
			<?php endif; ?>
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pokes\resources\views/projects/show.blade.php ENDPATH**/ ?>