<?php $__env->startSection('title'); ?>
<?php echo e(__('contac')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<h1><?php echo e(__('contac')); ?></h1>
<br>
	<?php echo $__env->make('partials.session-status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<form method="POST" action="<?php echo e(route('messages.store')); ?>">
		<?php echo csrf_field(); ?>
		<input name="name" placeholder="Nombre ..."values="<?php echo e(old('name')); ?>"><br>
		<?php echo $errors->first('name','<small>:message</small><br>'); ?>


		<input type="email" name="email" placeholder="Email ...""values="<?php echo e(old('email')); ?>"><br>
		<?php echo $errors->first('email','<small>:message</small><br>'); ?>


		<input name="subject" placeholder="Asunto ...""values="<?php echo e(old('subject')); ?>"><br>
		<?php echo $errors->first('subject','<small>:message</small><br>'); ?>


		<textarea name="content" placeholder="mensaje ..."<?php echo e(old('content')); ?>></textarea><br>
		<?php echo $errors->first('content','<small>:message</small><br>'); ?>


		<button>Enviar</button>

	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\intento\resources\views/contac.blade.php ENDPATH**/ ?>