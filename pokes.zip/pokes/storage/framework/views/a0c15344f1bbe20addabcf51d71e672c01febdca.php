<?php $__env->startSection('title', 'crear Productos'); ?>
<?php $__env->startSection('content'); ?>
<h1>crear  nuevo Productos </h1>



<?php echo $__env->make('partials.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<form method="POST" action="<?php echo e(route('projects.store')); ?>">

	<?php echo $__env->make('projects._form',['btnText'=>'Guardar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\intento\resources\views/projects/create.blade.php ENDPATH**/ ?>