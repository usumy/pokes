<?php $__env->startSection('title', 'Productos'); ?>
<?php $__env->startSection('content'); ?>
<h1><?php echo app('translator')->get('projects'); ?></h1>
<?php if(auth()->guard()->check()): ?>
<a href="<?php echo e(route('projects.create')); ?>">Crear Productos</a>
<?php endif; ?>
	<ul>
		<?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<li><a href="<?php echo e(route('projects.show',$project)); ?>"> <?php echo e($project->title); ?></a></li>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<li> no hay Productos para mostrar </li>
			<?php endif; ?>
			<?php echo e($projects->links()); ?>

	</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\intento\resources\views/projects/index.blade.php ENDPATH**/ ?>