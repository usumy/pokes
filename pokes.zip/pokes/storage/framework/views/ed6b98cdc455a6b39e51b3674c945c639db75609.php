<!-- resources/views/index.blade.php -->


<?php $__env->startSection('title', 'carrito'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Productos disponibles</h1>

    
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <h1><?php echo e($project->title); ?></h1>
                <h2><?php echo e($project->name); ?></h2>
                <p><?php echo e($project->description); ?></p>
                <p>Precio: $<?php echo e($project->imagen); ?></p>
                <form action="<?php echo e(route('cart.add')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                    <button type="submit">Agregar al carrito</button>
                </form>
          
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pokes\resources\views/cart.blade.php ENDPATH**/ ?>