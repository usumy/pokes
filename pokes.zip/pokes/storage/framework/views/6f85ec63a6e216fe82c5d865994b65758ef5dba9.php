<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>
Mensaje recibido
	</title>
</head>
<body>
<p>recibiste un mensaje de: <?php echo e($msg['name']); ?>-<?php echo e($msg['email']); ?></p>
<p><strong> asunto: </strong><?php echo e($msg['subject']); ?></p>
<p><strong> contenido: </strong><?php echo e($msg['content']); ?></p>
</body>
</html>
<?php /**PATH C:\laragon\www\intento\resources\views/emails/message-received.blade.php ENDPATH**/ ?>