<?php $__env->startSection('title'); ?>
<?php echo e(__('contac')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="cotainer">
	<div class="row">
		<div class="col-12 col-sm-10 col-lg-6 mx-auto">
		

<form class="bg-white shadow rounded py-3 px-4" 
	method="POST" 
	action="<?php echo e(route('messages.store')); ?>"
>
	<?php echo csrf_field(); ?>
	<h1 class="display-4"><?php echo app('translator')->get('contac'); ?></h1>
	<hr>
	<div class="form-goup">
		<label for="name">Nombre</label>
		<input class="form-control bg-light shadow-sm  
		<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
		id="name"
		name="name" 
		placeholder="Nombre ..."
		values="<?php echo e(old('name')); ?>"
		>
		<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span class="invalid-feedback" role="alert">
			<strong>
				<?php echo e($message); ?>

			</strong>
		</span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div class="form-goup">
		<label for="email">Email</label>
		<input class="form-control bg-light shadow-sm  
				<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			type="email" 
			id="email"
			name="email" 
			placeholder="Email ..."
			"values="<?php echo e(old('email')); ?>"
		>
		<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
			<span class="invalid-feedback" role="alert">
				<strong>
					<?php echo e($message); ?>

				</strong>
			</span>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	</div>
	<div class="form-goup">
		<label for="subject">asunto</label>
		<input class="form-control bg-light shadow-sm  
			<?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			id="subject"
			name="subject"
			placeholder="Asunto ..."
			"values="<?php echo e(old('subject')); ?>"
		>
	<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span class="invalid-feedback" role="alert">
			<strong>
				<?php echo e($message); ?>

			</strong>
		</span>
	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
		<div class="form-goup">
			<label for="content">contenido</label>
			<textarea class="form-control bg-light shadow-sm  
			<?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> border-0 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
			id="content"
			name="content" 
			 placeholder="mensaje ...">
			 <?php echo e(old('content')); ?>

	</textarea>
	<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		<span class="invalid-feedback" role="alert">
			<strong>
				<?php echo e($message); ?>

			</strong>
		</span>
		</div>
		<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

	<button class="btn btn-primary btn-lg btn-block"><?php echo app('translator')->get('send'); ?></button>

</form>
		</div>
	</div>
	
</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\planti\resources\views/contac.blade.php ENDPATH**/ ?>