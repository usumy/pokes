<?php $__env->startSection('title', 'Portafolio | '. $project->title); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="bg-white p-5 shadow rounded">
		<h1><?php echo e($project->title); ?></h1>
		<img src="<?php echo e(asset($project)); ?>" alt="$id">
		<p class="text-secondary">
			<?php echo e($project->description); ?></p>
		<p class="text-black-50">
			<?php echo e($project->created_at->diffForHumans()); ?></p>
		<div class="d-flex justify-content-between
		alinf-items-center">
			<a href="<?php echo e(route('projects.index')); ?>">Regresar</a>
			
				
			<?php if(auth()->guard()->check()): ?>
			<div class="btn-group btn-group-sm">
				<a class="btn btn-primary"
				href="<?php echo e(route('projects.edit',$project)); ?>">
				Editar</a>
				<a href="#" onclick="document.
				getElementByID('delete-project').
				submit()">Eliminar</a>
			</div>

			<form  id="delete-project"
			class="d-none"
			method="POST" 
			action="<?php echo e(route('projects.destroy', $project)); ?>">
			<?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
			</form>
			<?php endif; ?>
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\planti\resources\views/projects/show.blade.php ENDPATH**/ ?>