<?php echo csrf_field(); ?>
<label>
	Titulo del Productos <br>
	<input type="text" name="title" value="<?php echo e(old('title', $project->title)); ?>">
</label>
	<br>
<label>
	url del Productos <br>
	<input type="text" name="url" value="<?php echo e(old('url', $project->url)); ?>">
</label>
	<br>
<label>
	descripción del Productos <br>
	<textarea name="description"> <?php echo e(old('description', $project->description)); ?></textarea>
</label>
	<br>
	Seleccione imagen a cargar <br>
        <div class="form-group">
          <label class="col-sm-2 control-label">Archivos</label>
          <div class="col-sm-8">
            <input type="file" class="form-control" id="imagen" name="imagen" multiple>
          </div>
        </div>
	<br>
	<button> <?php echo e($btnText); ?> </button><?php /**PATH C:\laragon\www\intento\resources\views/projects/_form.blade.php ENDPATH**/ ?>