<nav class="navbar navbar-light navbar-expand-lg  bg-white shadow-sm">
	<div class="container">
		<a class="navbar-brand" href="<?php echo e(route('home')); ?>}">
			<?php echo e(config('app.name')); ?>

		</a>
		
		<div>
		 	
		
			<ul class="nav nav-pills">
				<li class="nav-item">
					<a class="nav-link <?php echo e(setActive('home')); ?>" 
					href="<?php echo e(route('about')); ?>">
						<?php echo app('translator')->get('home'); ?>

					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link <?php echo e(setActive('about')); ?> "
					 href="<?php echo e(route('about')); ?>">
						<?php echo app('translator')->get('about'); ?>
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link <?php echo e(setActive('projects.*')); ?>" 
					href="<?php echo e(route('projects.index')); ?>">
						<?php echo app('translator')->get('projects'); ?></a>
				</li>
				<li class="nav-item" >
					<a class="nav-link <?php echo e(setActive('contac')); ?>" 
					href="<?php echo e(route('contac')); ?>">
						<?php echo app('translator')->get('contac'); ?>
					</a>
				</li>
				<?php if(auth()->guard()->guest()): ?>
					<li class="nav-item">
						<a class="nav-link <?php echo e(setActive('login')); ?>" 
						href="<?php echo e(route('login')); ?>">
							Iniciar sesión 
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link <?php echo e(setActive('register')); ?>" 
						href="<?php echo e(route('register')); ?>">
							registrar
						</a>
					</li>
					<?php else: ?>
						<li class="nav-item" >
							<a class="nav-link"
							href="#" 
							onclick="event.preventDefault();
							document.getElementById('logout-form').submit();">
							Cerrar sesión 
							</a>
						</li>
				<?php endif; ?>
			</ul>

		</div>
	</div>
	</nav>
	 <form id="logout-form"
	  action="<?php echo e(route('logout')); ?>" 
	  method="POST" 
	  style="display: none;">
           <?php echo csrf_field(); ?>
     </form><?php /**PATH C:\laragon\www\pokes\resources\views/partials/nav.blade.php ENDPATH**/ ?>