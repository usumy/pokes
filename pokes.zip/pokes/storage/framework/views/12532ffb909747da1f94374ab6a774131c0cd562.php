<?php $__env->startSection('title','home'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-12 col-lg-6">

			<h1 class="display-4 text-primary"> 
				Bienvenidos a pokeshop </h1>
			<p class="lead text-secondary">
					
			</p>
			<a class="btn btn-lg btn-block btn-primary" 
			href="<?php echo e(route('contac')); ?>"> 
			Contáctame</a>
			<a class="btn btn-lg btn-block btn-ouline-primary"
			 href="<?php echo e(route('projects.index')); ?>">
			 Productos</a>
		</div>
		<div class="col-12 col-lg-6">
			<img  class="img-fluid mb-5" src="/img/home1.svg" 
			alt="ahhhh">
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pokes\resources\views/home.blade.php ENDPATH**/ ?>