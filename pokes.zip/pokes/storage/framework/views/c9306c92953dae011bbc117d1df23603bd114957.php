<?php $__env->startSection('title'); ?>
<?php echo e(__('home')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1><?php echo e(__('home')); ?></h1>
<?php if(auth()->guard()->check()): ?>
	<?php echo e(auth()->user()->name); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\intento\resources\views/home.blade.php ENDPATH**/ ?>