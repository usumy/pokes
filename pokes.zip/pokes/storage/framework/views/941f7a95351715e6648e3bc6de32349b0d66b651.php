	<nav>
		<ul>
			<li class="<?php echo e(setActive('home')); ?>"><a href="<?php echo e(route('about')); ?>"><?php echo app('translator')->get('home'); ?></a></li>
			<li class="<?php echo e(setActive('about')); ?>"><a href="<?php echo e(route('about')); ?>"><?php echo app('translator')->get('about'); ?></a></li>
			<li class="<?php echo e(setActive('projects.*')); ?>"><a href="<?php echo e(route('projects.index')); ?>"><?php echo app('translator')->get('projects'); ?></a></li>
			<li class="<?php echo e(setActive('contac')); ?>"><a href="<?php echo e(route('contac')); ?>"><?php echo app('translator')->get('contac'); ?></a></li>
			<?php if(auth()->guard()->guest()): ?>
				<li><a href="<?php echo e(route('login')); ?>">login</a></li>
				<?php else: ?>
					<li><a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Cerrar sesión </a></li>
			<?php endif; ?>
		</ul>
	</nav>
	 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
           <?php echo csrf_field(); ?>
     </form><?php /**PATH C:\laragon\www\intento\resources\views/partials/nav.blade.php ENDPATH**/ ?>