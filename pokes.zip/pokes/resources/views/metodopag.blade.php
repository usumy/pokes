<!DOCTYPE html>
<html>
<head>
    <title>Payment Methods</title>
    <link rel="stylesheet" href="{{ mix('css/app.css') }}">
</head>
<body>
    <h1>Payment Methods</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Created At</th>
                <th>Updated At</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($paymentMethods as $paymentMethod)
                <tr>
                    <td>{{ $paymentMethod->id }}</td>
                    <td>{{ $paymentMethod->name }}</td>
                    <td>{{ $paymentMethod->description }}</td>
                    <td>{{ $paymentMethod->created_at }}</td>
                    <td>{{ $paymentMethod->updated_at }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <script src="{{ mix('js/app.js') }}"></script>
</body>
</html>
