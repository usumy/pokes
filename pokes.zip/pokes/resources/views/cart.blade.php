<!-- resources/views/index.blade.php -->

@extends('layout')
@section('title', 'carrito')
@section('content')
    <h1>Productos disponibles</h1>

    
        @foreach ($projects as $project)
            
            <h1>{{$project->title}}</h1>
                <h2>{{ $project->name }}</h2>
                <p>{{ $project->description }}</p>
                <p>Precio: ${{ $project->imagen }}</p>
                <form action="{{ route('cart.add') }}" method="POST">
                    @csrf
                    <input type="hidden" name="project_id" value="{{ $project->id }}">
                    <button type="submit">Agregar al carrito</button>
                </form>
          
        @endforeach
    
@endsection
