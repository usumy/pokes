<nav class="navbar navbar-light navbar-expand-lg  bg-white shadow-sm">
	<div class="container">
		<a class="navbar-brand" href="{{ route('home')}}}">
			{{config('app.name')}}
		</a>
		
		<div>
		 	
		
			<ul class="nav nav-pills">
				<li class="nav-item">
					<a class="nav-link {{  setActive('home')}}" 
					href="{{route('about')}}">
						@lang('home')

					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link {{ setActive('about') }} "
					 href="{{route('about')}}">
						@lang('about')
					</a>
				</li>
				<li class="nav-item">
					<a class="nav-link {{ setActive('projects.*') }}" 
					href="{{route('projects.index')}}">
						@lang('projects')</a>
				</li>
				<li class="nav-item" >
					<a class="nav-link {{ setActive('contac') }}" 
					href="{{route('contac')}}">
						@lang('contac')
					</a>
				</li>
				@guest
					<li class="nav-item">
						<a class="nav-link {{ setActive('login') }}" 
						href="{{ route('login')}}">
							Iniciar sesión 
						</a>
					</li>
					<li class="nav-item">
						<a class="nav-link {{ setActive('register') }}" 
						href="{{ route('register')}}">
							registrar
						</a>
					</li>
					@else
						<li class="nav-item" >
							<a class="nav-link"
							href="#" 
							onclick="event.preventDefault();
							document.getElementById('logout-form').submit();">
							Cerrar sesión 
							</a>
						</li>
				@endguest
			</ul>

		</div>
	</div>
	</nav>
	 <form id="logout-form"
	  action="{{ route('logout') }}" 
	  method="POST" 
	  style="display: none;">
           @csrf
     </form>