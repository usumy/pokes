@extends('layout')

@section('title','home')

@section('content')

<div class="container">
	<div class="row">
		<div class="col-12 col-lg-6">

			<h1 class="display-4 text-primary"> 
				Bienvenidos a pokeshop </h1>
			<p class="lead text-secondary">
					
			</p>
			<a class="btn btn-lg btn-block btn-primary" 
			href="{{route('contac')}}"> 
			Contáctame</a>
			<a class="btn btn-lg btn-block btn-ouline-primary"
			 href="{{route('projects.index')}}">
			 Productos</a>
		</div>
		<div class="col-12 col-lg-6">
			<img  class="img-fluid mb-5" src="/img/home1.svg" 
			alt="ahhhh">
		</div>
	</div>
</div>
@endsection