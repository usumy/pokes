@extends('layout')
@section('title', 'Productos')
@section('content')


<div class="container">
	<div class="d-flex justify-content-between aligm-items-center mb-3">
		<h1 class="display-4 mb-0">@lang('projects')</h1>
		@auth
			<a  class="btn btn-primary"
			href="{{route('projects.create')}}">
			Crear Productos</a>
		@endauth
	</div>
	<form method="POST" action="/projects/search">
	@csrf
	<input type="text" name="keyword" placeholder="Buscar producto...">
	<button type="submit">Buscar</button>
	</form>
	@if ($projects instanceof LengthAwarePaginator)
	{{ $projects->links() }}
	@endif
	<p class="lead text-secondary">productos en venta</p>
			
	<ul class="list group">
			@forelse ($projects as $project)			
				<li class="list-group-item border-0 mb-3 shadow-sm">
					<a 
					class="text-secondary d-flex justify-content-between 
					aling-items-center"
					href="{{route('projects.show',$project)}}"> 
					<span class=" font-weight-bold">
					{{ $project->title }}
					</span>
					<span class="text-black-50"> 
					{{ $project->created_at->format('d/m/y')}}
					</span>
					</a>
				</li>

			@empty
			
			<li class="list-group-item border-0 mb-3 shadow-sm">
				 no hay Productos para mostrar 
				</li>
				@endforelse
				{{$projects->links()}}
		</ul>
</div>
@endsection