@csrf
	<div class="form-group">
		<label for="title"> Titulo del Productos </label>
			<input 
			id="title"
			type="text" 
			name="title" 
			value="{{old('title', $project->title)}}">
		
	</div>

	<div class="form-group">
		<label for="url"> URL del Producto </label>
			<input  class="form-control border-0 bg-light shadow-sm"
			 id="url"
			 type="text" 
			 name="url" 
			 value="{{old('url', $project->url)}}">
		
	</div>
	<div class="form-group">
		<label for="description"> Descripción del Productos </label>
		<textarea
		class="form-control border-0 bg-light shadow-sm" 
		name="description">
		{{old('description', $project->description)}}
		</textarea>
	
	</div>
	<p>selecione una imagen a cargar</p>
        <div class="form-group">
          <label class="col-sm-2 control-label">Archivos</label>
          <div class="col-sm-8">
				
            <input type="file" class="form-control"
			 id="imagen" 
			 name="imagen"
			 enctype="multipart/form-data"
			 accept="image/*"> 
			
			 {{old('imagen,$project->imagen')}}
          </div>
        </div>
	<button class="btn btn-primary btn-block"> {{$btnText}} </button>
	<a class="btn btn-link btn-block " 
	href="{{route('projects.index')}}">
	Cancelar </a>