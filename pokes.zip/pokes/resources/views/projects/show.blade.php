@extends('layout')
@section('title', 'Productos | '. $project->title)
@section('content')
<div class="container">
	<div class="bg-white p-5 shadow rounded">
		<h1>{{$project->title}}</h1>
		<div class="col-10 col-lg-5">
			<img src="{{ asset('$project->imagen') }}" alt="Imagen de ejemplo">
			<img  class="img-fluid mb-4" src="{{$project->imagen}}" alt="En unos momentos le muestro la imagen">
			
		</div>
		
		<img src="{{ asset($project) }}" alt="">
		<p class="text-secondary">
			{{$project->description}}</p>
		<p class="text-black-50">
			{{$project->created_at->diffForHumans()}}</p>
		<div class="d-flex justify-content-between
		alinf-items-center">
			<a href="{{route('projects.index')}}">Regresar</a>
			<form action="{{ route('cart.add') }}" method="POST">

@csrf

<input type="hidden" name="project_id" value="{{ $project->id }}">

<button type="submit">Agregar al carrito</button>

</form>

			
				
			@auth
			<div class="btn-group btn-group-sm">
				<a class="btn btn-primary"
				href="{{route('projects.edit',$project)}}">
				Editar</a>
				
				
				
			</div>
			<form  
				method="POST" 
				action="{{ route('projects.destroy', $project)}}">
				@csrf  @method('DELETE')
				<button>Eliminar</button>
				</form>
			
			@endauth
		</div>

	</div>
</div>
@endsection