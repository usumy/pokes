<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\shoppingcart;
use Faker\Generator as Faker;

$factory->define(shoppingcart::class, function (Faker $faker) {
    return [
        //
    ];
});
