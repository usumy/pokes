<?php

use Illuminate\Database\Seeder;

class ShoppingcartSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
