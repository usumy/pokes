<?php

namespace App\Http\Controllers;
use App\project;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\URL;
use Illuminate\Http\Request;
use App\Http\Requests\saveProjectRequest;
use Illuminate\Support\Facades\DB;


class projectcontroller extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $projects = Project::latest()->paginate(10);
        return view('projects.index', compact('projects'));
    }

        
    public function show(project $project)
    {
        
        return view('projects.show', [
            'project' => $project
           
        ]);
        
        $project = project::find($project);

       return view('projects.show', compact('project'));
    }
    public function view($id)
{
    
    return view('projects.view', [
        'project' => project::find($id)
       
    ]);

    return view('projects.view', compact('project'));
}
    public function create()
    {
        return view('projects.create',[
            'project'=> new project

        ]);
    }
    public function store(saveProjectRequest $request)
    {
         project::create($request->validated());
       
    
         return redirect()->route('projects.index')->with('status','El proyecto fue creado con éxito');
    }
   
    public function edit(project $project)
    {
        return view('projects.edit', [
            'project'=> $project
        ]);
    }
        public function update(project $project, saveProjectRequest $request)
    {
        $project->update( $request->validated());
        return redirect()->route('projects.show',$project)->with('status','el proyecto fue actualizado con éxito');
    }
    public function destroy(project $project)
    {
        $project->delete();

        return redirect()->route('projects.index')->with('status','El proyecto fue eliminado con exito.');
    }
   public function __construct()
   {
    $this->middleware('auth')->except('index','show');
   }
   
   public function search(Request $request)
    {
        $projects = Project::latest()->paginate(10);
        Paginator::defaultView('pagination::bootstrap-4');
        $keyword = $request->input('keyword');
        $projects = Project::where('title',"%$keyword%")->get();
        return view('projects.index', ['projects' => $projects]);
;
    }
   /*public function getImage($id)
    {
    $project = Product::find($id);

    if (!$project) {
        return abort(404);
    }

    //return response()->make($project->image, 200, [
      //  'Content-Type' => 'image/jpeg', // Ajusta el tipo de contenido según tu imagen
        //'Content-Disposition' => 'inline; filename="' . $project->filename . '"',
    //]);
    }
    */

}
 
