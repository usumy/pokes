<?php

namespace App\Http\Controllers;
use App\product;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;

class ProductControlle extends Controller
{
    public function index()
    {
        return view ('products.index',[
            ' products'=>product::latest()->paginate()
        ]);

    }
    public function show(product $product)
    {
        $product = product::find($product);

        return view('products.show', compact('products'));
    }
}
