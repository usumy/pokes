<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\MessageReceived;
use Illuminate\Support\Facades\Mail;

class Messagecontroller extends Controller
{
    public function store(Request $request)
    {
       $message = request()->validate([
            'name'=> 'required',
            'email' => 'required|email',
            'subject'=> 'required',
            'content'=> 'required|min:3'

        ],[
            'name.required'=> __('Ingresa tu nombre')
        ]);
        Mail::to('tiendaplantimx@gmail.com')->queue(new MessageReceived($message));
        return back()->with('status','recibimos tu mensaje, te responderemos pronto.');

    }
}
