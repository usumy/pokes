<?php

namespace App\Http\Controllers;
use App\project;
use Illuminate\Http\Request;
use App\Http\Requests\saveProjectRequest;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    public function addToCart(Request $request, $project)
    {
        $project = project::findOrFail($project);
        
        // Agregar el producto al carrito (por ejemplo, almacenarlo en la sesión)
        $cart = $request->session()->get('cart', []);
        $cart[$project->id] = $project;
        $request->session()->put('cart', $cart);
        
        return redirect()->back()->with('success', 'Producto agregado al carrito.');
    }
    
    public function removeFromCart(Request $request, $project)
    {
        // Eliminar el producto del carrito (por ejemplo, eliminarlo de la sesión)
        $cart = $request->session()->get('cart', []);
        unset($cart[$project]);
        $request->session()->put('cart', $cart);
        
        return redirect()->back()->with('success', 'Producto eliminado del carrito.');
    }
    
    public function showCart(Request $request)
    {
        $cart = $request->session()->get('cart', []);
        
        return view('cart', compact('cart'));
    }
}
