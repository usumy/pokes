<?php
use Illuminate\Support\Facades\Route;

route::view('/','home')->name('home');
route::view('/quienes-somos','about')->name('about');

Route::resource('portafolio','projectcontroller')
->names('projects')
->parameters(['portafolio'=>'project']);
Route::post('/projects/search', 'ProjectController@search');
Route::get('/payment-methods', 'PaymentMethodController@index');
//Route::get('/portafolio/{project}', 'projectController@showImage');

Route::view('/cart','cart')->name('cart');
Route::post('/cart/add','CartController@addToCart')-> name('cart.add');
Route::post('/cart/remove','CartController@removeFromCart')->name('cart.remove');



route::view('/contacto','contac')->name('contac');
Route::post('contac','Messagecontroller@store')->name('messages.store');


Auth::routes([]);


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
